import streamlit as st
from sentence_transformers import SentenceTransformer

from qa_service import answer_question
from qa_service import generate_study_plan_prompt
from qa_service import generate_mcq_prompt
from file_handler import extract_uploaded_file_text
from vector_store import vectorize_document, search_similar_chunks


# =========================
# PAGE CONFIG
# =========================
st.set_page_config(
    page_title="AI Study Assistant",
    page_icon="📚",
    layout="wide"
)


# =========================
# LOAD MODEL
# =========================
@st.cache_resource
def load_embedding_model():
    return SentenceTransformer(
        "sentence-transformers/paraphrase-MiniLM-L3-v2",
        device="cpu"
    )


# =========================
# SESSION STATE
# =========================
if "notes_text" not in st.session_state:
    st.session_state.notes_text = ""

if "faiss_index" not in st.session_state:
    st.session_state.faiss_index = None

if "document_chunks" not in st.session_state:
    st.session_state.document_chunks = []


# =========================
# SIDEBAR
# =========================
st.sidebar.title("⚙️ Settings")

provider = st.sidebar.selectbox(
    "Pilih AI Provider",
    ["gemini", "openai"]
)

st.sidebar.info(
    "Upload dokumen, lakukan vectorization, lalu gunakan fitur study plan, quiz, atau tanya dokumen."
)


# =========================
# MAIN TITLE
# =========================
st.title("📚 AI Study Assistant")
st.write(
    "Aplikasi pembelajaran berbasis AI untuk membuat study plan, quiz, dan menjawab pertanyaan berdasarkan dokumen."
)

st.divider()


# =========================
# INPUT DATA
# =========================
st.header("📝 Input Data Belajar")

col1, col2 = st.columns(2)

with col1:
    goal = st.text_input(
        "Goal / Tujuan Belajar",
        placeholder="Contoh: Memahami sistem pernapasan manusia"
    )

    subject = st.text_input(
        "Subject / Mata Pelajaran",
        placeholder="Contoh: Biologi"
    )

with col2:
    time = st.text_input(
        "Time / Waktu Belajar",
        placeholder="Contoh: 5 hari"
    )

    topic = st.text_input(
        "Topic / Topik Materi",
        placeholder="Contoh: Sistem pernapasan manusia"
    )

st.divider()


# =========================
# DOCUMENT UPLOAD
# =========================
st.header("📄 Upload PDF / Notes")

uploaded_file = st.file_uploader(
    "Upload catatan belajar",
    type=["pdf", "txt"]
)

if uploaded_file is not None:
    notes_text = extract_uploaded_file_text(uploaded_file)

    if notes_text.startswith("Error") or notes_text.startswith("Format"):
        st.error(notes_text)
    else:
        st.session_state.notes_text = notes_text
        st.success("File berhasil dibaca.")

        with st.expander("Lihat isi catatan"):
            st.text_area(
                "Isi catatan",
                st.session_state.notes_text,
                height=250
            )


# =========================
# VECTORIZATION
# =========================
st.header("🧩 Document Vectorization")

if st.session_state.notes_text:
    if st.button("Vectorize Document"):
        try:
            with st.spinner("Sedang mengubah dokumen menjadi vector embeddings..."):
                embedding_model = load_embedding_model()

                faiss_index, chunks = vectorize_document(
                    st.session_state.notes_text,
                    embedding_model
                )

                st.session_state.faiss_index = faiss_index
                st.session_state.document_chunks = chunks

            if faiss_index is not None:
                st.success(
                    f"Dokumen berhasil dimasukkan ke FAISS index dengan {len(chunks)} chunks."
                )
            else:
                st.warning("Dokumen tidak memiliki teks yang bisa diproses.")

        except Exception as e:
            st.error(f"Terjadi error saat vectorization: {e}")
else:
    st.info("Upload PDF/TXT terlebih dahulu untuk melakukan vectorization.")

st.divider()


# =========================
# DOCUMENT Q&A
# =========================
st.header("💬 Ask Questions from Uploaded Document")

document_question = st.text_input(
    "Pertanyaan dari dokumen",
    placeholder="Contoh: Apa inti pembahasan dari dokumen ini?"
)

if st.button("Ask Document"):
    if not document_question:
        st.warning("Harap isi pertanyaan terlebih dahulu.")

    elif st.session_state.faiss_index is None or not st.session_state.document_chunks:
        st.warning("Upload dan vectorize dokumen terlebih dahulu.")

    else:
        with st.spinner("Sedang mencari jawaban dari dokumen..."):
            try:
                embedding_model = load_embedding_model()

                relevant_chunks = search_similar_chunks(
                    query=document_question,
                    index=st.session_state.faiss_index,
                    chunks=st.session_state.document_chunks,
                    model=embedding_model,
                    top_k=3
                )

                context = "\n\n".join(relevant_chunks)

                prompt = f"""
Jawab pertanyaan user hanya berdasarkan isi dokumen berikut.

Jika jawaban tidak ditemukan di dokumen, katakan:
"Jawaban tidak ditemukan dalam dokumen yang diupload."

Isi dokumen yang relevan:
{context}

Pertanyaan:
{document_question}

Aturan jawaban:
- Gunakan bahasa Indonesia.
- Jawab dengan jelas dan singkat.
- Jangan mengarang jawaban di luar dokumen.
"""

                result = answer_question(
                    question=prompt,
                    provider=provider
                )

                st.subheader("📌 Jawaban Berdasarkan Dokumen")
                st.markdown(result)

                with st.expander("Lihat potongan dokumen yang digunakan"):
                    st.write(context)

            except Exception as e:
                st.error(f"Terjadi error saat menjawab pertanyaan dokumen: {e}")

st.divider()


# =========================
# STUDY PLAN
# =========================
st.header("📅 Generate Day-wise Study Plan")

if st.button("Generate Study Plan"):
    if goal and time and subject:
        with st.spinner("Sedang membuat rencana belajar..."):
            try:
                prompt = generate_study_plan_prompt(
                    goal=goal,
                    time=time,
                    subject=subject
                )

                if st.session_state.faiss_index is not None and st.session_state.document_chunks:
                    embedding_model = load_embedding_model()

                    relevant_chunks = search_similar_chunks(
                        query=f"{subject} {goal}",
                        index=st.session_state.faiss_index,
                        chunks=st.session_state.document_chunks,
                        model=embedding_model,
                        top_k=3
                    )

                    context = "\n\n".join(relevant_chunks)

                    prompt += f"""

Gunakan potongan materi berikut sebagai sumber utama:

{context}
"""

                result = answer_question(
                    question=prompt,
                    provider=provider
                )

                st.subheader("📚 Day-wise Study Plan")
                st.markdown(result)

            except Exception as e:
                st.error(f"Terjadi error saat membuat study plan: {e}")
    else:
        st.warning("Harap isi goal, time, dan subject terlebih dahulu.")

st.divider()


# =========================
# MCQ
# =========================
st.header("🧠 Generate Multiple Choice Questions")

col3, col4 = st.columns(2)

with col3:
    total_questions = st.number_input(
        "Jumlah Soal MCQ",
        min_value=1,
        max_value=20,
        value=5
    )

with col4:
    difficulty = st.selectbox(
        "Quiz Difficulty / Tingkat Kesulitan",
        ["Easy", "Medium", "Hard"]
    )

if st.button("Generate MCQ"):
    if goal and subject and topic:
        with st.spinner("Sedang membuat soal pilihan ganda..."):
            try:
                prompt = generate_mcq_prompt(
                    subject=subject,
                    goal=goal,
                    topic=topic,
                    total_questions=total_questions,
                    difficulty=difficulty
                )

                if st.session_state.faiss_index is not None and st.session_state.document_chunks:
                    embedding_model = load_embedding_model()

                    relevant_chunks = search_similar_chunks(
                        query=topic,
                        index=st.session_state.faiss_index,
                        chunks=st.session_state.document_chunks,
                        model=embedding_model,
                        top_k=3
                    )

                    context = "\n\n".join(relevant_chunks)

                    prompt += f"""

Gunakan potongan materi berikut sebagai sumber utama:

{context}
"""

                result = answer_question(
                    question=prompt,
                    provider=provider
                )

                st.subheader(f"📝 Multiple Choice Questions - {difficulty}")
                st.markdown(result)

            except Exception as e:
                st.error(f"Terjadi error saat membuat MCQ: {e}")
    else:
        st.warning("Harap isi goal, subject, dan topic terlebih dahulu.")


# =========================
# FOOTER
# =========================
st.divider()
st.caption("AI Study Assistant | Streamlit UI | Powered by Gemini/OpenAI + HuggingFace + FAISS")