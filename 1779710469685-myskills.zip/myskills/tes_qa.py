from qa_service import answer_question

sample_questions = [
    "Apa itu kecerdasan buatan?",
    "Apa manfaat AI dalam pendidikan?",
    "Bagaimana cara kerja sistem tanya jawab berbasis AI?",
    "Apa kelebihan Gemini dan OpenAI API?",
    "Apa contoh penerapan AI di sekolah?"
]

for i, question in enumerate(sample_questions, start=1):
    print(f"\nPertanyaan {i}: {question}")
    print("Jawaban:")
    
    try:
        answer = answer_question(question, provider="gemini")
        print(answer)
    except Exception as e:
        print(f"Error: {e}")