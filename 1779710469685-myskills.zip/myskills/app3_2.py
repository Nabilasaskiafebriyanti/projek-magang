import streamlit as st
from qa_service import answer_question, generate_study_plan_prompt

st.set_page_config(page_title="AI Study Assistant", page_icon="📚")

st.title("📚 AI Study Assistant")

goal = st.text_input(
    "Goal / Tujuan Belajar",
    placeholder="Contoh: Memahami sistem pernapasan manusia"
)

time = st.text_input(
    "Time / Waktu Belajar",
    placeholder="Contoh: 5 hari"
)

subject = st.text_input(
    "Subject / Mata Pelajaran",
    placeholder="Contoh: Biologi"
)

if st.button("Generate Study Plan"):
    if goal and time and subject:
        prompt = generate_study_plan_prompt(goal, time, subject)
        result = answer_question(prompt, provider="gemini")

        st.subheader("📚 Day-wise Study Plan")
        st.markdown(result)
    else:
        st.warning("Harap isi semua field: goal, time, dan subject.")