import streamlit as st
from sentence_transformers import SentenceTransformer

from qa_service import answer_question
from qa_service import generate_study_plan_prompt
from qa_service import generate_mcq_prompt
from file_handler import extract_uploaded_file_text
from vector_store import vectorize_document, search_similar_chunks


# =========================
# PAGE CONFIG
# =========================
st.set_page_config(
    page_title="AI Study Assistant",
    page_icon="📚",
    layout="centered"
)


# =========================
# LOAD MODEL
# =========================
@st.cache_resource
def load_embedding_model():
    return SentenceTransformer(
        "sentence-transformers/paraphrase-MiniLM-L3-v2",
        device="cpu"
    )


# =========================
# SESSION STATE
# =========================
if "notes_text" not in st.session_state:
    st.session_state.notes_text = ""

if "document_embeddings" not in st.session_state:
    st.session_state.document_embeddings = None

if "document_chunks" not in st.session_state:
    st.session_state.document_chunks = []


# =========================
# TITLE
# =========================
st.title("📚 AI Study Assistant")
st.write(
    "Aplikasi ini membantu membuat rencana belajar harian, soal pilihan ganda, dan membaca catatan PDF/TXT menggunakan AI."
)


# =========================
# SIDEBAR
# =========================
st.sidebar.header("⚙️ Settings")

provider = st.sidebar.selectbox(
    "Pilih AI Provider",
    ["gemini", "openai"]
)


# =========================
# INPUT SECTION
# =========================
st.header("📝 Input Data Belajar")

goal = st.text_input(
    "Goal / Tujuan Belajar",
    placeholder="Contoh: Memahami sistem pernapasan manusia"
)

time = st.text_input(
    "Time / Waktu Belajar",
    placeholder="Contoh: 5 hari"
)

subject = st.text_input(
    "Subject / Mata Pelajaran",
    placeholder="Contoh: Biologi"
)

topic = st.text_input(
    "Topic / Topik Materi",
    placeholder="Contoh: Sistem pernapasan manusia"
)


# =========================
# UPLOAD PDF / NOTES
# =========================
st.header("📄 Upload PDF / Notes")

uploaded_file = st.file_uploader(
    "Upload catatan belajar",
    type=["pdf", "txt"]
)

if uploaded_file is not None:
    notes_text = extract_uploaded_file_text(uploaded_file)

    if notes_text.startswith("Error") or notes_text.startswith("Format"):
        st.error(notes_text)
    else:
        st.session_state.notes_text = notes_text
        st.success("File berhasil dibaca.")

        with st.expander("Lihat isi catatan"):
            st.text_area(
                "Isi catatan",
                st.session_state.notes_text,
                height=250
            )


# =========================
# VECTORIZATION
# =========================
st.header("🧩 Vectorization")

if st.session_state.notes_text:
    if st.button("Vectorize Document"):
        try:
            with st.spinner("Sedang mengubah dokumen menjadi vector embeddings..."):
                embedding_model = load_embedding_model()

                embeddings, chunks = vectorize_document(
                    st.session_state.notes_text,
                    embedding_model
                )

                st.session_state.document_embeddings = embeddings
                st.session_state.document_chunks = chunks

            if embeddings is not None:
                st.success(
                    f"Dokumen berhasil divektorisasi menjadi {len(chunks)} chunks."
                )
            else:
                st.warning("Dokumen tidak memiliki teks yang bisa diproses.")

        except Exception as e:
            st.error(f"Terjadi error saat vectorization: {e}")
else:
    st.info("Upload PDF/TXT terlebih dahulu untuk melakukan vectorization.")


# =========================
# STUDY PLAN SECTION
# =========================
st.header("📅 Generate Day-wise Study Plan")

if st.button("Generate Study Plan"):
    if goal and time and subject:
        with st.spinner("Sedang membuat rencana belajar..."):
            try:
                prompt = generate_study_plan_prompt(
                    goal=goal,
                    time=time,
                    subject=subject
                )

                if (
                    st.session_state.document_embeddings is not None
                    and st.session_state.document_chunks
                ):
                    embedding_model = load_embedding_model()

                    relevant_chunks = search_similar_chunks(
                        query=f"{subject} {goal}",
                        embeddings=st.session_state.document_embeddings,
                        chunks=st.session_state.document_chunks,
                        model=embedding_model,
                        top_k=3
                    )

                    context = "\n\n".join(relevant_chunks)

                    prompt += f"""

Gunakan potongan materi berikut sebagai sumber utama dalam membuat study plan:

{context}
"""

                elif st.session_state.notes_text:
                    prompt += f"""

Gunakan catatan berikut sebagai sumber tambahan:

{st.session_state.notes_text[:3000]}
"""

                result = answer_question(
                    question=prompt,
                    provider=provider
                )

                st.subheader("📚 Day-wise Study Plan")
                st.markdown(result)

            except Exception as e:
                st.error(f"Terjadi error saat membuat study plan: {e}")
    else:
        st.warning("Harap isi goal, time, dan subject terlebih dahulu.")


# =========================
# MCQ SECTION
# =========================
st.header("🧠 Generate Multiple Choice Questions")

total_questions = st.number_input(
    "Jumlah Soal MCQ",
    min_value=1,
    max_value=20,
    value=5
)

difficulty = st.selectbox(
    "Quiz Difficulty / Tingkat Kesulitan",
    ["Easy", "Medium", "Hard"]
)

if st.button("Generate MCQ"):
    if goal and subject and topic:
        with st.spinner("Sedang membuat soal pilihan ganda..."):
            try:
                prompt = generate_mcq_prompt(
                    subject=subject,
                    goal=goal,
                    topic=topic,
                    total_questions=total_questions,
                    difficulty=difficulty
                )

                if (
                    st.session_state.document_embeddings is not None
                    and st.session_state.document_chunks
                ):
                    embedding_model = load_embedding_model()

                    relevant_chunks = search_similar_chunks(
                        query=topic,
                        embeddings=st.session_state.document_embeddings,
                        chunks=st.session_state.document_chunks,
                        model=embedding_model,
                        top_k=3
                    )

                    context = "\n\n".join(relevant_chunks)

                    prompt += f"""

Gunakan potongan materi berikut sebagai sumber utama dalam membuat soal:

{context}
"""

                elif st.session_state.notes_text:
                    prompt += f"""

Gunakan catatan berikut sebagai sumber tambahan:

{st.session_state.notes_text[:3000]}
"""

                result = answer_question(
                    question=prompt,
                    provider=provider
                )

                st.subheader(f"📝 Multiple Choice Questions - {difficulty}")
                st.markdown(result)

            except Exception as e:
                st.error(f"Terjadi error saat membuat MCQ: {e}")
    else:
        st.warning("Harap isi goal, subject, dan topic terlebih dahulu.")


# =========================
# FOOTER
# =========================
st.divider()
st.caption("AI Study Assistant | Powered by Gemini/OpenAI + HuggingFace")