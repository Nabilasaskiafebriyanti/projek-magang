import streamlit as st
from qa_service import answer_question
from qa_service import generate_study_plan_prompt
from qa_service import generate_mcq_prompt

st.set_page_config(page_title="AI Study Assistant", page_icon="📚")

st.title("📚 AI Study Assistant")

goal = st.text_input(
    "Goal / Tujuan Belajar",
    placeholder="Contoh: Memahami sistem pernapasan manusia"
)

time = st.text_input(
    "Time / Waktu Belajar",
    placeholder="Contoh: 5 hari"
)

subject = st.text_input(
    "Subject / Mata Pelajaran",
    placeholder="Contoh: Biologi"
)

topic = st.text_input(
    "Topic / Topik Materi",
    placeholder="Contoh: Sistem pernapasan manusia"
)

total_questions = st.number_input(
    "Jumlah Soal MCQ",
    min_value=1,
    max_value=20,
    value=5
)

if st.button("Generate Study Plan"):
    if goal and time and subject:
        prompt = generate_study_plan_prompt(goal, time, subject)
        result = answer_question(prompt, provider="gemini")

        st.subheader("📚 Day-wise Study Plan")
        st.markdown(result)
    else:
        st.warning("Harap isi goal, time, dan subject.")

if st.button("Generate MCQ"):
    if goal and subject and topic:
        prompt = generate_mcq_prompt(
            subject=subject,
            goal=goal,
            topic=topic,
            total_questions=total_questions
        )

        result = answer_question(prompt, provider="gemini")

        st.subheader("📝 Multiple Choice Questions")
        st.markdown(result)
    else:
        st.warning("Harap isi goal, subject, dan topic.")