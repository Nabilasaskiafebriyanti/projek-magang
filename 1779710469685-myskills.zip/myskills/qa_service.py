import os
from dotenv import load_dotenv
from openai import OpenAI
from google import genai

load_dotenv()

openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
gemini_client = genai.Client(api_key=os.getenv("GEMINI_API_KEY"))


def format_prompt(question: str) -> str:
    return f"""
Jawab pertanyaan berikut dalam bentuk bullet points yang rapi, singkat, dan mudah dipahami.

Pertanyaan:
{question}

Format jawaban:
- Poin pertama
- Poin kedua
- Poin ketiga
"""


def ask_openai(question: str) -> str:
    prompt = format_prompt(question)

    response = openai_client.responses.create(
        model="gpt-4.1-mini",
        input=prompt
    )

    return response.output_text


def ask_gemini(question: str) -> str:
    prompt = format_prompt(question)

    response = gemini_client.models.generate_content(
        model="gemini-2.5-flash",
        contents=prompt
    )

    return response.text


def answer_question(question: str, provider: str = "gemini") -> str:
    if provider == "openai":
        return ask_openai(question)
    elif provider == "gemini":
        return ask_gemini(question)
    else:
        return "- Provider tidak valid. Pilih 'gemini' atau 'openai'."

# def generate_study_plan_prompt(goal: str, time: str, subject: str) -> str:
#     return f"""
# Buatkan rencana belajar harian dalam bentuk day-wise study plan.

# Data siswa:
# - Tujuan belajar: {goal}
# - Waktu belajar tersedia: {time}
# - Mata pelajaran: {subject}

# Aturan jawaban:
# - Bagi rencana belajar berdasarkan hari.
# - Gunakan format Day 1, Day 2, Day 3, dan seterusnya.
# - Setiap hari berisi materi yang harus dipelajari.
# - Tambahkan aktivitas belajar singkat.
# - Tambahkan review atau latihan soal di hari terakhir.
# - Gunakan bahasa yang sederhana dan mudah dipahami.

# Format jawaban:
# - Day 1: ...
# - Day 2: ...
# - Day 3: ...
# """

def generate_study_plan_prompt(goal: str, time: str, subject: str) -> str:
    return f"""
Buatkan rencana belajar harian yang rapi dan mudah dibaca.

Data siswa:
- Tujuan belajar: {goal}
- Waktu belajar tersedia: {time}
- Mata pelajaran: {subject}

Aturan format:
- Buat dalam bentuk day-wise study plan.
- Gunakan format Day 1, Day 2, Day 3, dan seterusnya.
- Setiap hari harus memiliki:
  1. Topik
  2. Aktivitas belajar
  3. Target belajar
- Gunakan bullet points.
- Gunakan bahasa sederhana.
- Jangan membuat paragraf panjang.
- Hari terakhir harus berisi review dan latihan soal.

Format jawaban wajib seperti ini:

📅 Day 1: Judul Materi
- Topik: ...
- Aktivitas: ...
- Target: ...

📅 Day 2: Judul Materi
- Topik: ...
- Aktivitas: ...
- Target: ...

📅 Day 3: Review dan Latihan
- Topik: ...
- Aktivitas: ...
- Target: ...
"""

def generate_mcq_prompt(subject: str, goal: str, topic: str, total_questions: int = 5) -> str:
    return f"""
Buatkan {total_questions} soal pilihan ganda / Multiple Choice Questions (MCQ).

Data:
- Mata pelajaran: {subject}
- Tujuan belajar: {goal}
- Topik materi: {topic}

Aturan soal:
- Buat soal yang sesuai dengan topik.
- Setiap soal memiliki 4 pilihan jawaban: A, B, C, dan D.
- Hanya ada 1 jawaban yang benar.
- Sertakan kunci jawaban.
- Sertakan penjelasan singkat kenapa jawaban tersebut benar.
- Gunakan bahasa Indonesia yang mudah dipahami.
- Jangan membuat soal terlalu sulit.

Format jawaban wajib:

1. Pertanyaan: ...
   A. ...
   B. ...
   C. ...
   D. ...
   Jawaban: ...
   Penjelasan: ...

2. Pertanyaan: ...
   A. ...
   B. ...
   C. ...
   D. ...
   Jawaban: ...
   Penjelasan: ...
"""

# def generate_mcq_prompt(
#     subject: str,
#     goal: str,
#     topic: str,
#     total_questions: int = 5,
#     difficulty: str = "Medium"
# ) -> str:
#     return f"""
# Buatkan {total_questions} soal pilihan ganda / Multiple Choice Questions (MCQ).

# Data:
# - Mata pelajaran: {subject}
# - Tujuan belajar: {goal}
# - Topik materi: {topic}
# - Tingkat kesulitan: {difficulty}

# Aturan tingkat kesulitan:
# - Easy: soal dasar, bahasa sederhana, cocok untuk pemula.
# - Medium: soal tingkat menengah, membutuhkan pemahaman konsep.
# - Hard: soal lebih sulit, membutuhkan analisis dan penalaran.

# Aturan soal:
# - Buat soal sesuai dengan tingkat kesulitan yang dipilih.
# - Setiap soal memiliki 4 pilihan jawaban: A, B, C, dan D.
# - Hanya ada 1 jawaban yang benar.
# - Sertakan kunci jawaban.
# - Sertakan penjelasan singkat kenapa jawaban tersebut benar.
# - Gunakan bahasa Indonesia yang jelas dan mudah dipahami.

# Format jawaban wajib:

# 1. Pertanyaan: ...
#    A. ...
#    B. ...
#    C. ...
#    D. ...
#    Jawaban: ...
#    Penjelasan: ...

# 2. Pertanyaan: ...
#    A. ...
#    B. ...
#    C. ...
#    D. ...
#    Jawaban: ...
#    Penjelasan: ...
# """

def generate_mcq_prompt(
    subject: str,
    goal: str,
    topic: str,
    total_questions: int = 5,
    difficulty: str = "Medium"
) -> str:
    return f"""
Buatkan {total_questions} soal pilihan ganda / Multiple Choice Questions (MCQ).

Data:
- Mata pelajaran: {subject}
- Tujuan belajar: {goal}
- Topik materi: {topic}
- Tingkat kesulitan: {difficulty}

Aturan tingkat kesulitan:
- Easy: soal dasar, bahasa sederhana, cocok untuk pemula.
- Medium: soal tingkat menengah, membutuhkan pemahaman konsep.
- Hard: soal lebih sulit, membutuhkan analisis dan penalaran.

Aturan pembuatan soal:
- Setiap soal harus memiliki 4 pilihan jawaban: A, B, C, dan D.
- Setiap soal wajib memiliki 1 jawaban benar.
- Setiap soal wajib memiliki 3 jawaban salah.
- Jawaban salah harus masuk akal, tetapi tetap jelas salah.
- Jangan membuat pilihan jawaban yang terlalu mirip sampai membingungkan.
- Jangan membuat semua jawaban benar.
- Jangan membuat pilihan seperti "semua benar" atau "semua salah".
- Posisi jawaban benar harus bervariasi, jangan selalu di pilihan A.
- Sertakan kunci jawaban.
- Sertakan penjelasan singkat kenapa jawaban benar tersebut tepat.
- Gunakan bahasa Indonesia yang jelas dan mudah dipahami.

Format jawaban wajib:

1. Pertanyaan: ...
   A. ...
   B. ...
   C. ...
   D. ...
   Jawaban Benar: ...
   Jawaban Salah: ..., ..., ...
   Penjelasan: ...

2. Pertanyaan: ...
   A. ...
   B. ...
   C. ...
   D. ...
   Jawaban Benar: ...
   Jawaban Salah: ..., ..., ...
   Penjelasan: ...
"""