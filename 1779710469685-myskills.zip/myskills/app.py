from qa_service import answer_question

question = "Apa itu AI dalam pendidikan?"
answer = answer_question(question, provider="gemini")

print(answer)