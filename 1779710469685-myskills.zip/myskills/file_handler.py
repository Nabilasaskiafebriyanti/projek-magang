from pypdf import PdfReader


def extract_text_from_pdf(uploaded_file) -> str:
    """
    Mengambil teks dari file PDF yang diupload user.
    """
    text = ""

    try:
        reader = PdfReader(uploaded_file)

        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"

        return text.strip()

    except Exception as e:
        return f"Error membaca PDF: {e}"


def extract_text_from_txt(uploaded_file) -> str:
    """
    Mengambil teks dari file TXT yang diupload user.
    """
    try:
        return uploaded_file.read().decode("utf-8")

    except UnicodeDecodeError:
        uploaded_file.seek(0)
        return uploaded_file.read().decode("latin-1")

    except Exception as e:
        return f"Error membaca TXT: {e}"


def extract_uploaded_file_text(uploaded_file) -> str:
    """
    Mengecek tipe file lalu mengambil teksnya.
    """
    if uploaded_file is None:
        return ""

    file_name = uploaded_file.name.lower()

    if file_name.endswith(".pdf"):
        return extract_text_from_pdf(uploaded_file)

    elif file_name.endswith(".txt"):
        return extract_text_from_txt(uploaded_file)

    else:
        return "Format file tidak didukung. Upload file PDF atau TXT."