import streamlit as st
from qa_service import answer_question
from qa_service import generate_study_plan_prompt
from qa_service import generate_mcq_prompt
from file_handler import extract_uploaded_file_text


# =========================
# PAGE CONFIG
# =========================
st.set_page_config(
    page_title="AI Study Assistant",
    page_icon="📚",
    layout="centered"
)


# =========================
# TITLE
# =========================
st.title("📚 AI Study Assistant")
st.write(
    "Aplikasi ini membantu membuat rencana belajar harian dan soal pilihan ganda menggunakan AI."
)


# =========================
# SIDEBAR PROVIDER
# =========================
st.sidebar.header("⚙️ Settings")

provider = st.sidebar.selectbox(
    "Pilih AI Provider",
    ["gemini", "openai"]
)


# =========================
# INPUT SECTION
# =========================
st.header("📝 Input Data Belajar")

goal = st.text_input(
    "Goal / Tujuan Belajar",
    placeholder="Contoh: Memahami sistem pernapasan manusia"
)

time = st.text_input(
    "Time / Waktu Belajar",
    placeholder="Contoh: 5 hari"
)

subject = st.text_input(
    "Subject / Mata Pelajaran",
    placeholder="Contoh: Biologi"
)

topic = st.text_input(
    "Topic / Topik Materi",
    placeholder="Contoh: Sistem pernapasan manusia"
)

st.header("📄 Upload PDF / Notes")

uploaded_file = st.file_uploader(
    "Upload catatan belajar",
    type=["pdf", "txt"]
)

notes_text = ""

if uploaded_file is not None:
    notes_text = extract_uploaded_file_text(uploaded_file)

    if notes_text.startswith("Error") or notes_text.startswith("Format"):
        st.error(notes_text)
    else:
        st.success("File berhasil dibaca.")
        
        with st.expander("Lihat isi catatan"):
            st.text_area(
                "Isi catatan",
                notes_text,
                height=250
            )


# =========================
# STUDY PLAN SECTION
# =========================
st.header("📅 Generate Day-wise Study Plan")

if st.button("Generate Study Plan"):
    if goal and time and subject:
        with st.spinner("Sedang membuat rencana belajar..."):
            try:
                prompt = generate_study_plan_prompt(
                    goal=goal,
                    time=time,
                    subject=subject
                )
                if notes_text:
                    prompt += f"""

                Gunakan juga catatan berikut sebagai sumber materi utama:

                {notes_text}
                """

                result = answer_question(
                    question=prompt,
                    provider=provider
                )

                st.subheader("📚 Day-wise Study Plan")
                st.markdown(result)

            except Exception as e:
                st.error(f"Terjadi error saat membuat study plan: {e}")
    else:
        st.warning("Harap isi goal, time, dan subject terlebih dahulu.")


# =========================
# MCQ SECTION
# =========================
st.header("🧠 Generate Multiple Choice Questions")

total_questions = st.number_input(
    "Jumlah Soal MCQ",
    min_value=1,
    max_value=20,
    value=5
)

difficulty = st.selectbox(
    "Quiz Difficulty / Tingkat Kesulitan",
    ["Easy", "Medium", "Hard"]
)

if st.button("Generate MCQ"):
    if goal and subject and topic:
        with st.spinner("Sedang membuat soal pilihan ganda..."):
            try:
                prompt = generate_mcq_prompt(
                    subject=subject,
                    goal=goal,
                    topic=topic,
                    total_questions=total_questions,
                    difficulty=difficulty
                )
                if notes_text:
                    prompt += f"""

                Gunakan juga catatan berikut sebagai sumber materi utama:

                {notes_text}
                """

                result = answer_question(
                    question=prompt,
                    provider=provider
                )

                st.subheader(f"📝 Multiple Choice Questions - {difficulty}")
                st.markdown(result)

            except Exception as e:
                st.error(f"Terjadi error saat membuat MCQ: {e}")
    else:
        st.warning("Harap isi goal, subject, dan topic terlebih dahulu.")


# =========================
# FOOTER
# =========================
st.divider()
st.caption("AI Study Assistant | Powered by Gemini/OpenAI")