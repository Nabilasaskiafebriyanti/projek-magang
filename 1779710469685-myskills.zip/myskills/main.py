import streamlit as st
from qa_service import answer_question

st.set_page_config(page_title="AI Study Assistant", page_icon="📚")

st.title("📚 AI Study Assistant")
st.write("Masukkan tujuan belajar, waktu, dan mata pelajaran untuk mendapatkan bantuan dari AI.")

goal = st.text_input(
    "Goal / Tujuan Belajar",
    placeholder="Contoh: Saya ingin memahami materi fotosintesis"
)

time = st.text_input(
    "Time / Waktu Belajar",
    placeholder="Contoh: 30 menit"
)

subject = st.text_input(
    "Subject / Mata Pelajaran",
    placeholder="Contoh: Biologi"
)

if st.button("Generate Answer"):
    if goal and time and subject:
        prompt = f"""
Buatkan panduan belajar dalam bentuk bullet points.

Tujuan belajar: {goal}
Waktu belajar: {time}
Mata pelajaran: {subject}

Berikan jawaban yang singkat, jelas, dan mudah dipahami.
"""
        result = answer_question(prompt, provider="gemini")

        st.subheader("Hasil:")
        st.write(result)
    else:
        st.warning("Harap isi semua field: goal, time, dan subject.")