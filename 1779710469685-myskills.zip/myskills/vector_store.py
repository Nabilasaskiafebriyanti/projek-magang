import numpy as np
import faiss


def split_text_into_chunks(text, chunk_size=500, overlap=100, max_chunks=30):
    if not text:
        return []

    text = text.replace("\n", " ").strip()

    chunks = []
    start = 0

    while start < len(text) and len(chunks) < max_chunks:
        end = start + chunk_size
        chunk = text[start:end].strip()

        if chunk:
            chunks.append(chunk)

        start += chunk_size - overlap

    return chunks


def create_embeddings(chunks, model):
    embeddings = model.encode(
        chunks,
        convert_to_numpy=True,
        normalize_embeddings=True,
        batch_size=4,
        show_progress_bar=False
    )

    return embeddings.astype("float32")


def create_faiss_index(embeddings):
    if embeddings is None or len(embeddings) == 0:
        return None

    dimension = embeddings.shape[1]

    index = faiss.IndexFlatIP(dimension)
    index.add(embeddings)

    return index


def vectorize_document(text, model):
    chunks = split_text_into_chunks(text)

    if not chunks:
        return None, []

    embeddings = create_embeddings(chunks, model)
    faiss_index = create_faiss_index(embeddings)

    return faiss_index, chunks


def search_similar_chunks(query, index, chunks, model, top_k=3):
    if index is None or not chunks:
        return []

    query_embedding = model.encode(
        [query],
        convert_to_numpy=True,
        normalize_embeddings=True,
        show_progress_bar=False
    ).astype("float32")

    scores, indices = index.search(query_embedding, top_k)

    results = []

    for idx in indices[0]:
        if 0 <= idx < len(chunks):
            results.append(chunks[idx])

    return results